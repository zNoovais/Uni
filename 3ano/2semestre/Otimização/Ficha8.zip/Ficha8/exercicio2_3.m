
%%%%%%%%% run Algoritmo de M�todo da Penalidade Quadr�tica %%%%%%%%%%%%

clear all;
clc;
format short e

%--- Problema a resolver HS6: 
% solu��o �tima w* = [1;1] f*=0
n=2;
w0=[-1.2;1];

mu0=10;  %1; 10 
   

% Usar o M�todo de Penalidade Quadr�tica para resolver o problema 
% 1� definir e fun��o de penalidade quadr�tica passar como input ao algoritmo
[wopt,Qopt,violation,output1] = MetodoPenalidadeQuadratica(@penaltyQ_HS6,@HS6,w0, mu0)


% Display the results
k=output1(end,1);

disp(['Number of the subproblems solved:', num2str(k)]);
disp('Optimal Solution:'); 
wopt=wopt'
%calcular f e as restri��es na solu��o �tima
[fopt,c_opt,ceq_opt]=HS6(wopt')
%mostar o valor da fun��o de penalidade quadr�tica em wopt e a viola��o
disp(['Qopt = ', num2str(Qopt)]);
disp (['violation value = ', num2str(violation)]);






