
%%%%%%%%% run Algoritmo de M�todo da Penalidade L1 %%%%%%%%%%%%

clear all;
clc;
format short e

%--- Problema a resolver P2: 
% solu��o �tima w* = [0;0;1] f*=1
n=3;
w0=[0;0;0];

mu0=1;  %1; 10 
   

% Usar o M�todo de Penalidade L1 para resolver o problema 
% 1� definir e fun��o de penalidade L1 passar como input ao algoritmo
[wopt,penL1opt,violation,output1] = MetodoPenalidadeL1(@penaltyL1_P2,@P2, w0, mu0)


% Display the results
k=output1(end,1);

disp(['Number of the subproblems solved:', num2str(k)]);
disp('Optimal Solution:'); 
wopt=wopt'
%calcular f e as restri��es na solu��o �tima
[fopt,c_opt,ceq_opt]=P2(wopt')
%mostar o valor da fun��o de penalidade L1 em wopt e a viola��o
disp(['penL1opt = ', num2str(penL1opt)]);
disp (['violation value = ', num2str(violation)]);






