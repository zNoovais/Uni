
%%%%%%%%% run Algoritmo do M�todo da Penalidade L1 %%%%%%%%%%%%

clear all;
clc;
format short e

%--- Problema a resolver P1: solu��o �tima w* = [-1;-1] f*=-2
n=2;
w0=[0; 0];

mu0=1;  %1; 10 
   

% Usar o M�todo de Penalidade L1 para resolver o problema 
% 1� definir e fun��o de penalidade L1 passar como input ao algoritmo
[wopt,penL1opt,violation,output1] = MetodoPenalidadeL1(@penaltyL1_P1,@P1, w0, mu0)


% Display the results
k=output1(end,1);

disp(['Number of the subproblems solved:', num2str(k)]);
disp('Optimal Solution:'); 
wopt=wopt'
%calcular f e as restri��es na solu��o �tima
[fopt,c_opt,ceq_opt]=P1(wopt')
%mostar o valor da fun��o de penalidade L1 em wopt e a viola��o
disp(['penL1opt = ', num2str(penL1opt)]);
disp (['violation value = ', num2str(violation)]);






